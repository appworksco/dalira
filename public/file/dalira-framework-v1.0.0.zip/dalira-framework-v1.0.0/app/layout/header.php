<?php

// Start session management and output buffering
session_start();
ob_start();

// Array to store invalid and success messages
$invalid = array();
$success = array();

// Include necessary files for database connectivity and facade classes
include(__DIR__ . '/../../config/db/connector.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Appworks Co.">
    <!-- Template CSS -->
    <link rel="stylesheet" href="./vendor/twbs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./vendor/twbs/bootstrap-icons/font/bootstrap-icons.min.css">
    <title>Dalira Framework | A lightweight PHP starter template</title>
</head>

<body>