<footer>

</footer>

<!-- Template JS -->
<script src="./vendor/twbs/bootstrap/dist/js/bootstrap.min.js"></script>

</body>

</html>